# cs61a_fall2020
My solutions to the labs, homework, and projects auditing the CS61a. https://inst.eecs.berkeley.edu/~cs61a/fa20/
